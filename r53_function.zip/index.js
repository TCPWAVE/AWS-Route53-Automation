console.log('Loading function');

exports.handler = async (event, context, callback) => {
    var ORG_NAME = "xxxx";
    var HOST = "xxx.xxxx.xxx";
    var KEY = "client.key";
    var CERT = "client.crt";
	
    var AWS = require('aws-sdk');
    var data = event;
    console.log('Received event:', JSON.stringify(event, null, 2));
    var zoneId = data.hostedZoneId;
    console.log("Zone ID: ", zoneId);
    
    //Get Zone Name from AWS
    const route53 = new AWS.Route53();
    var zparams = {
      Id: zoneId
    };
    var zoneObj= await route53.getHostedZone(zparams).promise();
    if(zoneObj==null)
    {
        console.error("There is no such zone.");
        return;
    }
    
    var arn = "arn:aws:route53:::hostedzone/"+zoneId;
    var tparams = {
      ResourceId: zoneId,
      ResourceType: "hostedzone"
    };
   
    var tagsObj  = await route53.listTagsForResource(tparams).promise()
   
    if(tagsObj!=null)
    {
        console.log("Tags: "+JSON.stringify(tagsObj, null, 2));
        var tags = tagsObj.ResourceTagSet.Tags;
        if(tags !=null)
        {
            for (var i = 0; i<tags.length; i++)
            {
                var n = tags[i].Key;
                var v = tags[i].Value;
                if("ORGANIZATION" == n)
                {
                    ORG_NAME = v;
                    break;
                }
            }
        }
        console.log("Organzation tag: "+ORG_NAME);
    }
    
    var zoneName = zoneObj.HostedZone.Name.slice(0,-1);
    console.log("Zone name: "+zoneName);
     
    var changeBatch = event.changeBatch;
    if(changeBatch==null)
    {
        console.log("There is no changeBatch.");
        return;
    }
    //console.log("Change batch: ",changeBatch);
    var changes = changeBatch.changes;
    if(changes==null)
    {
        console.log("There are no changes.");
        return;
    }
    //console.log("Changes: ",changes);
    for(var i=0; i<changes.length;i++)
    {
        var change = changes[i];
        var action = change.action;
        console.log("Action"+i+" "+action);
        var rrSet = change.resourceRecordSet;
        if(rrSet == null)
        {
            console.log("There is no resourceRecordSet.");
            return;
        }
        var type =  rrSet.type;
        var ownerOrig = rrSet.name;
        const index = ownerOrig.lastIndexOf("."+zoneName);
        var owner = ownerOrig.slice(0, index);
        var records = rrSet.resourceRecords;
        var ttl = rrSet.tTL;
        var record = records[0];
        var value = record.value;
        
        console.log("Resource Record: "+owner+" "+type+" "+value+" "+ttl);
        
        var path;
        var reqData = {};
        reqData.organization_name = ORG_NAME;
        reqData.rrtype = type;
        reqData.rrclass = "IN";
        reqData.data = value;
        reqData.zoneName = zoneName;
        reqData.source = "cloud";
        
        if(action == 'DELETE')
        {
          reqData.owner = ownerOrig;
          path = '/tims/rest/zone/rr/delete';
          
        }
        else if(action == 'CREATE')
        {
          reqData.owner = owner;
          path = '/tims/rest/zone/rr/add';
        }
        
        var https = require('https');
        const tls = require('tls');
        var fs = require('fs');
        var options = {
            host: HOST,
            port: '7443',
            path: path,
            method: 'POST',
            key: fs.readFileSync(KEY),
            cert: fs.readFileSync(CERT)
        };
        process.env['NODE_TLS_REJECT_UNAUTHORIZED'] = '0';
        var postHeaders = {'Content-Type':'application/json'};
        var jsonObject;
        if ( reqData )
        {
            jsonObject = JSON.stringify(reqData);
        }
        if ( jsonObject )
        {
            console.log(' ');
            console.log(jsonObject);
            postHeaders["Content-Length"] = Buffer.byteLength(jsonObject, 'utf8');
       }
       options.headers = postHeaders;
       console.log("Headers:"+postHeaders);
       var reqPost = https.request(options, function(res){
       console.log("Status Code: ", res.statusCode);
        res.on('data', function(d){
          process.stdout.write(d);
        });
      });
      if ( jsonObject )
       reqPost.write(jsonObject);
      else
       reqPost.write("{}");
    
      reqPost.on('error', function(e){
        console.error('Error: '+e);
      });
    }// successful response
  
 
    callback(null, 'Route53Updatefunction execution completed.');
};

